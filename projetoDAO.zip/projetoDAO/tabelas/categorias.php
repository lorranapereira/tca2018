<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SB Admin - Tables</title>

    <!-- Bootstrap core CSS-->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    
    <!-- Custom styles for this template-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

  </head>


  <body id="page-top">
      <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
          <a class="navbar-brand" href="../index.html">Logo</a>          
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Cadastro
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="../cadastros/filme.html">Filmes</a>
              <a class="dropdown-item" href="../cadastros/ator.html">Atores</a>
              <a class="dropdown-item" href="../cadastros/categoria.html">Categorias</a>
            </div>
          </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle active" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Tabelas
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="../tabelas/filme.html">Filme</a>
                  <a class="dropdown-item" href="../tabelas/atores.html">Atores</a>
                  <a class="dropdown-item active" href="../tabelas/categorias.html">Categorias</a>
                </div>
              </li>
        </ul>
        </div>
  
      </nav>
      <div class="container">
        <div id="content-wrapper">

          <div class="container-fluid">

            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item active">
                  Tabelas
                </li>
                <li class="breadcrumb-item">Categorias</li>
              </ol>
    
            <!-- DataTables Example -->
            <div class="card mb-3">
              <div class="card-header">
                <i class="fas fa-table"></i>
                Tabela Categorias
                <a href="../cadastros/categoria.html" class="btn btn-primary" style="position: relative; color:white; left:80%;"> Adicionar</a> 
                
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                      <tr>
                        <th>Código</th>
                        <th>Nome</th> 
                        <th>Editar</th>                    
                        <th>Excluir</th>                    
                        
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>01</td>
                        <td>Filme</td>
                        <td><a href="../cadastros/categoria.html"><span class="glyphicon glyphicon-pencil"></span>                        
                        </td>
                        <td><a href="#"><span class="glyphicon glyphicon-remove"></span></a>
                        </td>
                      </tr>
                      <tbody>
                        <tr>
                          <td>02</td>
                          <td>Série</td>
                          <td><a href="../cadastros/categoria.html"><span class="glyphicon glyphicon-pencil"></span>                        
                          </td>
                          <td><a href="#"><span class="glyphicon glyphicon-remove"></span></a>
                          </td>
                        </tr>
                      <tr>
                        <td>03</td>
                        <td>Desenho</td>
                        <td><a href="../cadastros/categoria.html"><span class="glyphicon glyphicon-pencil"></span>                        
                        </td>    
                        <td><a href="#"><span class="glyphicon glyphicon-remove"></span></a>
                        </td>                
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

        </div>
      </div>
    </div>
    <footer class="sticky-footer" style="width:100%; position:relative; top:15em;">
        <div class="container my-auto">
            <div class="copyright text-center my-auto" style="font-size:13px;">
              <span>Sistema Administrador © Site de filmes 2018</span>
            </div>
          </div>
    </footer>    

  <!-- /#wrapper -->

    <!-- Scroll to Top Button-->


    <!-- Logout Modal-->

    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->


    <!-- Custom scripts for all pages-->

  </body>

</html>
